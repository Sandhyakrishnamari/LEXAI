// ── /api/chat ─────────────────────────────────────────────────
const express  = require('express');
const Anthropic = require('@anthropic-ai/sdk');
const { validateChat } = require('../middleware/validate');
const { buildChatPrompt } = require('../config/prompts');
const config = require('../config');

const router = express.Router();
const anthropic = new Anthropic({ apiKey: config.anthropicApiKey });

// ── POST /api/chat ────────────────────────────────────────────
router.post('/', validateChat, async (req, res, next) => {
  try {
    const {
      messages,
      lang  = 'en',
      state = 'Tamil Nadu',
      area  = 'Contract Law',
      mode  = 'explain',
    } = req.body;

    const systemPrompt = buildChatPrompt({ lang, state, area, mode });

    const response = await anthropic.messages.create({
      model:      config.model,
      max_tokens: config.maxTokens,
      system:     systemPrompt,
      messages:   messages,
    });

    res.json({
      reply:        response.content[0].text,
      inputTokens:  response.usage.input_tokens,
      outputTokens: response.usage.output_tokens,
      model:        response.model,
    });

  } catch (err) {
    next(err);
  }
});

// ── POST /api/chat/stream ─────────────────────────────────────
router.post('/stream', validateChat, async (req, res, next) => {
  try {
    const {
      messages,
      lang  = 'en',
      state = 'Tamil Nadu',
      area  = 'Contract Law',
      mode  = 'explain',
    } = req.body;

    const systemPrompt = buildChatPrompt({ lang, state, area, mode });

    // Set SSE headers
    res.setHeader('Content-Type',  'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection',    'keep-alive');
    res.flushHeaders();

    const stream = anthropic.messages.stream({
      model:      config.model,
      max_tokens: config.maxTokens,
      system:     systemPrompt,
      messages:   messages,
    });

    stream.on('text', (text) => {
      res.write(`data: ${JSON.stringify({ type: 'delta', text })}\n\n`);
    });

    stream.on('message', (msg) => {
      res.write(`data: ${JSON.stringify({
        type:         'done',
        inputTokens:  msg.usage.input_tokens,
        outputTokens: msg.usage.output_tokens,
      })}\n\n`);
      res.end();
    });

    stream.on('error', (err) => {
      res.write(`data: ${JSON.stringify({ type: 'error', message: err.message })}\n\n`);
      res.end();
    });

    // Clean up if client disconnects
    req.on('close', () => stream.abort());

  } catch (err) {
    next(err);
  }
});

module.exports = router;
