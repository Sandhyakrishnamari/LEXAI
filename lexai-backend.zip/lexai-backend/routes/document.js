// ── /api/document ─────────────────────────────────────────────
const express   = require('express');
const Anthropic  = require('@anthropic-ai/sdk');
const { validateDocument } = require('../middleware/validate');
const { buildDocPrompt }   = require('../config/prompts');
const config = require('../config');

const router    = express.Router();
const anthropic = new Anthropic({ apiKey: config.anthropicApiKey });

const DOC_NAMES = {
  rent_agreement:    'Residential Rent Agreement (11-Month)',
  nda:               'Non-Disclosure Agreement',
  legal_notice:      'Legal Notice',
  employment_offer:  'Employment Offer Letter',
  affidavit:         'General Affidavit',
  consumer_complaint:'Consumer Complaint – District Consumer Forum',
};

// ── POST /api/document ────────────────────────────────────────
router.post('/', validateDocument, async (req, res, next) => {
  try {
    const { docType, state = 'Tamil Nadu' } = req.body;

    const docName = DOC_NAMES[docType];
    const systemPrompt = buildDocPrompt(state);
    const userMsg = `Generate a complete, professional ${docName} template under Indian law for ${state}. Include all essential clauses, [FIELD_NAME] placeholders for all variable information, and DOCUMENT NOTES at the end.`;

    const response = await anthropic.messages.create({
      model:      config.model,
      max_tokens: config.maxTokens,
      system:     systemPrompt,
      messages:   [{ role: 'user', content: userMsg }],
    });

    res.json({
      docType,
      docName,
      state,
      content:      response.content[0].text,
      inputTokens:  response.usage.input_tokens,
      outputTokens: response.usage.output_tokens,
    });

  } catch (err) {
    next(err);
  }
});

// ── GET /api/document/types ───────────────────────────────────
router.get('/types', (req, res) => {
  res.json({ types: DOC_NAMES });
});

module.exports = router;
