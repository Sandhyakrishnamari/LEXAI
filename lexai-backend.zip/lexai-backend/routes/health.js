// ── /api/health ───────────────────────────────────────────────
const express = require('express');
const config  = require('../config');
const router  = express.Router();

router.get('/', (req, res) => {
  res.json({
    status:    'ok',
    service:   'LexAI India Backend',
    version:   '1.0.0',
    model:     config.model,
    env:       config.nodeEnv,
    timestamp: new Date().toISOString(),
    apiKeySet: !!config.anthropicApiKey,
  });
});

module.exports = router;
