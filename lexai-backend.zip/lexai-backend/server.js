// ═══════════════════════════════════════════════════════════════
//  LexAI India — Backend Server
//  Express + Anthropic SDK | Node.js 18+
// ═══════════════════════════════════════════════════════════════
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');

const config          = require('./config');
const chatRoute       = require('./routes/chat');
const documentRoute   = require('./routes/document');
const healthRoute     = require('./routes/health');
const { errorHandler } = require('./middleware/errorHandler');

// ── Validate env ──────────────────────────────────────────────
if (!config.anthropicApiKey) {
  console.error('❌  ANTHROPIC_API_KEY is not set in .env — exiting.');
  process.exit(1);
}

const app = express();

// ── Security headers ──────────────────────────────────────────
app.use(helmet());

// ── CORS ──────────────────────────────────────────────────────
app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (curl, Postman, server-to-server)
    if (!origin) return callback(null, true);
    if (config.allowedOrigins.includes(origin)) return callback(null, true);
    callback(new Error(`CORS blocked for origin: ${origin}`));
  },
  methods:     ['GET', 'POST'],
  credentials: true,
}));

// ── Body parsing ──────────────────────────────────────────────
app.use(express.json({ limit: '100kb' }));

// ── Request logging ───────────────────────────────────────────
app.use(morgan(config.nodeEnv === 'production' ? 'combined' : 'dev'));

// ── Global rate limiter ───────────────────────────────────────
const limiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max:      config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders:   false,
  message: {
    error: `Too many requests. Max ${config.rateLimit.max} per minute. Please slow down.`,
  },
});
app.use('/api/', limiter);

// ── Routes ────────────────────────────────────────────────────
app.use('/api/health',   healthRoute);
app.use('/api/chat',     chatRoute);
app.use('/api/document', documentRoute);

// ── 404 handler ───────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` });
});

// ── Error handler (must be last) ──────────────────────────────
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────
app.listen(config.port, () => {
  console.log(`
  ╔══════════════════════════════════════════╗
  ║        LexAI India — Backend             ║
  ║  ⚡  http://localhost:${config.port}              ║
  ║  🤖  Model : ${config.model}    ║
  ║  🌍  Env   : ${config.nodeEnv.padEnd(12)}              ║
  ╚══════════════════════════════════════════╝
  `);
});

module.exports = app;
