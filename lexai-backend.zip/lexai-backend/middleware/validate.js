// ── Input Validation Middleware ───────────────────────────────

const VALID_LANGS  = ['en', 'ta'];
const VALID_MODES  = ['explain', 'scenario', 'xai', 'rights'];
const VALID_STATES = [
  'Tamil Nadu', 'Maharashtra', 'Karnataka', 'Delhi', 'West Bengal',
  'Gujarat', 'Rajasthan', 'Uttar Pradesh', 'Kerala', 'Andhra Pradesh', 'Telangana',
];
const VALID_DOC_TYPES = [
  'rent_agreement', 'nda', 'legal_notice',
  'employment_offer', 'affidavit', 'consumer_complaint',
];

function validateChat(req, res, next) {
  const { messages, lang, state, area, mode } = req.body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages array is required and must not be empty' });
  }
  if (messages.length > 50) {
    return res.status(400).json({ error: 'Conversation history too long (max 50 messages)' });
  }
  for (const m of messages) {
    if (!['user', 'assistant'].includes(m.role)) {
      return res.status(400).json({ error: `Invalid role: ${m.role}` });
    }
    if (typeof m.content !== 'string' || m.content.trim().length === 0) {
      return res.status(400).json({ error: 'Each message must have non-empty string content' });
    }
    if (m.content.length > 4000) {
      return res.status(400).json({ error: 'Message content too long (max 4000 chars)' });
    }
  }
  if (lang && !VALID_LANGS.includes(lang)) {
    return res.status(400).json({ error: `Invalid lang. Must be one of: ${VALID_LANGS.join(', ')}` });
  }
  if (mode && !VALID_MODES.includes(mode)) {
    return res.status(400).json({ error: `Invalid mode. Must be one of: ${VALID_MODES.join(', ')}` });
  }
  if (state && !VALID_STATES.includes(state)) {
    return res.status(400).json({ error: `Invalid state. Must be one of: ${VALID_STATES.join(', ')}` });
  }

  next();
}

function validateDocument(req, res, next) {
  const { docType, state } = req.body;

  if (!docType || !VALID_DOC_TYPES.includes(docType)) {
    return res.status(400).json({ error: `Invalid docType. Must be one of: ${VALID_DOC_TYPES.join(', ')}` });
  }
  if (state && !VALID_STATES.includes(state)) {
    return res.status(400).json({ error: `Invalid state. Must be one of: ${VALID_STATES.join(', ')}` });
  }

  next();
}

module.exports = { validateChat, validateDocument };
