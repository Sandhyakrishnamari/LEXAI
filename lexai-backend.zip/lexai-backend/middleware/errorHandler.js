// ── Centralised Error Handler ─────────────────────────────────

function errorHandler(err, req, res, next) {
  console.error(`[${new Date().toISOString()}] ERROR:`, err.message);

  // Anthropic API errors
  if (err.status) {
    const statusMap = {
      400: 'Bad request to AI API',
      401: 'Invalid Anthropic API key — check server .env',
      429: 'Anthropic rate limit or quota exceeded. Try again shortly.',
      500: 'Anthropic server error. Please retry.',
      529: 'Anthropic API overloaded. Please retry in a moment.',
    };
    return res.status(err.status).json({
      error: statusMap[err.status] || err.message,
      type:  err.error?.type || 'api_error',
    });
  }

  // Generic
  res.status(500).json({
    error: process.env.NODE_ENV === 'production'
      ? 'Internal server error'
      : err.message,
  });
}

module.exports = { errorHandler };
