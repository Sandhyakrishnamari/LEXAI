# LexAI India — Backend

**Node.js + Express backend** for LexAI India legal chatbot.  
Handles all Anthropic API calls server-side — API key never exposed to the browser.

---

## Tech Stack

| Layer        | Technology                          |
|--------------|-------------------------------------|
| Runtime      | Node.js 18+                         |
| Framework    | Express 4                           |
| AI SDK       | @anthropic-ai/sdk                   |
| Security     | Helmet, CORS, express-rate-limit    |
| Logging      | Morgan                              |
| Dev          | Nodemon                             |

---

## Project Structure

```
lexai-backend/
├── server.js               ← Entry point
├── package.json
├── .env.example            ← Copy to .env and fill in
├── config/
│   ├── index.js            ← Config loader
│   └── prompts.js          ← All NLP prompt builders
├── routes/
│   ├── chat.js             ← POST /api/chat  &  POST /api/chat/stream
│   ├── document.js         ← POST /api/document
│   └── health.js           ← GET  /api/health
├── middleware/
│   ├── validate.js         ← Input validation
│   └── errorHandler.js     ← Centralised error handling
└── public/
    └── index.html          ← Frontend (calls backend instead of Anthropic directly)
```

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Set up environment
```bash
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

### 3. Run development server
```bash
npm run dev
# Server starts at http://localhost:3000
```

### 4. Open the frontend
Open `public/index.html` in your browser (use Live Server or any static server).

---

## API Endpoints

### `GET /api/health`
Health check.
```json
{ "status": "ok", "model": "claude-sonnet-4-5", "env": "development" }
```

---

### `POST /api/chat`
Send a legal query.

**Request:**
```json
{
  "messages": [{ "role": "user", "content": "What is Section 498A?" }],
  "lang":  "en",
  "state": "Tamil Nadu",
  "area":  "Criminal Law (IPC/CrPC)",
  "mode":  "scenario"
}
```

**Response:**
```json
{
  "reply": "Section 498A of IPC...",
  "inputTokens": 312,
  "outputTokens": 847,
  "model": "claude-sonnet-4-5"
}
```

**Valid values:**
- `lang`: `en` | `ta`
- `mode`: `explain` | `scenario` | `xai` | `rights`
- `state`: Tamil Nadu, Maharashtra, Karnataka, Delhi, West Bengal, Gujarat, Rajasthan, Uttar Pradesh, Kerala, Andhra Pradesh, Telangana

---

### `POST /api/chat/stream`
Same as `/api/chat` but returns SSE stream.

**Response (SSE events):**
```
data: {"type":"delta","text":"Section "}
data: {"type":"delta","text":"498A "}
data: {"type":"done","inputTokens":312,"outputTokens":847}
```

---

### `POST /api/document`
Generate a legal document template.

**Request:**
```json
{
  "docType": "rent_agreement",
  "state":   "Tamil Nadu"
}
```

**Response:**
```json
{
  "docType":  "rent_agreement",
  "docName":  "Residential Rent Agreement (11-Month)",
  "state":    "Tamil Nadu",
  "content":  "RESIDENTIAL RENT AGREEMENT\n\nThis agreement...",
  "inputTokens": 280,
  "outputTokens": 1240
}
```

**Valid docType values:**
`rent_agreement` | `nda` | `legal_notice` | `employment_offer` | `affidavit` | `consumer_complaint`

---

### `GET /api/document/types`
List all available document types.

---

## Rate Limiting
- 30 requests per minute per IP (configurable in `.env`)
- Returns `429` with a clear message when exceeded

## Security
- API key stored only in `.env` — never sent to browser
- All inputs validated and sanitised
- Helmet sets security headers
- CORS restricted to allowed origins only
