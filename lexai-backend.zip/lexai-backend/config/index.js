require('dotenv').config();

module.exports = {
  port: parseInt(process.env.PORT) || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  anthropicApiKey: process.env.ANTHROPIC_API_KEY,
  model: process.env.MODEL || 'claude-sonnet-4-5',
  maxTokens: parseInt(process.env.MAX_TOKENS) || 8192,
  allowedOrigins: (process.env.ALLOWED_ORIGINS || 'http://localhost:5500')
    .split(',').map(o => o.trim()),
  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 60000,
    max: parseInt(process.env.RATE_LIMIT_MAX) || 30,
  },
};
