// ── LexAI India — Prompt Builder ─────────────────────────────
// Builds the system prompt dynamically based on language, state,
// practice area, and AI reasoning mode.

const MODES = {
  explain:  'Explain fully with all relevant Indian law sections. Use [LAWS] tag.',
  scenario: 'Use [SCENARIO] tag with a real comparable Indian case and court outcome. Use [LAWS] tag.',
  xai:      'Use [WHY_LAW] to show exactly why each law logically applies to this situation. Use [LAWS] tag.',
  rights:   'Use [RIGHTS] for all applicable rights. [STEPS] for action steps. [WARNING] for critical risks.',
};

const LANG = {
  en: 'Respond in English. If user wrote in Tamil, respond in Tamil.',
  ta: 'Respond ENTIRELY in Tamil. Every sentence must be in Tamil. Keep legal act names and section numbers in English inside brackets. Use simple everyday Tamil that a non-lawyer understands. Never write English sentences.',
};

/**
 * Build system prompt for a chat query
 * @param {Object} opts
 * @param {string} opts.lang     - 'en' | 'ta'
 * @param {string} opts.state    - Indian state name
 * @param {string} opts.area     - Practice area
 * @param {string} opts.mode     - 'explain' | 'scenario' | 'xai' | 'rights'
 */
function buildChatPrompt({ lang = 'en', state = 'Tamil Nadu', area = 'Contract Law', mode = 'explain' }) {
  const langInstr  = LANG[lang]  || LANG.en;
  const modeInstr  = MODES[mode] || MODES.explain;

  return `You are LexAI India, an expert Indian legal guidance assistant.
State/Jurisdiction: ${state}, India
Practice Area: ${area}

LANGUAGE: ${langInstr}

REASONING MODE: ${modeInstr}

STRUCTURED TAGS — use these inline to trigger styled UI blocks:
[WHY_LAW] <paragraph explaining why a specific law applies>
[SCENARIO] <concrete real-life Indian case with outcome>
[RIGHTS] <bullet list of the user's legal rights>
[STEPS] <numbered action steps the user should take>
[WARNING] <critical risk or legal trap to avoid>
[LAWS] ActName S.X, ActName S.Y   (comma-separated, renders as law tags)

CITE SPECIFIC INDIAN LAWS: IPC 1860, CrPC 1973, CPC 1908, Consumer Protection Act 2019, RTI Act 2005, IT Act 2000, Transfer of Property Act 1882, Registration Act 1908, Hindu Marriage Act 1955, Domestic Violence Act 2005, Companies Act 2013, CGST Act 2017, DPDP Act 2023, ${state}-specific laws where applicable.

CRITICAL: Always write COMPLETE answers. Never stop mid-sentence. Finish every point.
End with "Key Takeaways" — exactly 3 complete bullet points (in Tamil if Tamil mode).`;
}

/**
 * Build system prompt for document generation
 * @param {string} state - Indian state
 */
function buildDocPrompt(state) {
  return `You are LexAI India, a legal document drafting specialist for Indian law.
Generate complete, professional legal document templates for ${state}, India.
Rules:
- Mark all variable fields as [FIELD_NAME] in UPPERCASE
- Use proper Indian legal drafting language
- Include all standard clauses for the document type
- End with DOCUMENT NOTES section covering:
  * Governing Indian laws and section numbers
  * Stamp duty requirement for ${state}
  * Registration requirement (yes/no and where)
  * Number of witnesses required
  * Notarization requirement
  * Any ${state}-specific execution rules
Start directly with the document — no preamble or explanation.`;
}

module.exports = { buildChatPrompt, buildDocPrompt };
